<?php
session_start();
echo "<script>location.href='login.php'</script>";
session_destroy();
?>