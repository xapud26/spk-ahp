
	<footer class="text-center">&copy;Apudin | 2113201048</footer><hr>
	</div>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="assets/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.toastmessage.js"></script>
		<script type="text/javascript" src="assets/js/app.js"></script>
  </body>
</html>
